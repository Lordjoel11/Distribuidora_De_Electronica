package com.Districto_Tech.distribuidora.features.employees;

import com.Districto_Tech.distribuidora.common.IModelMapper;
import com.Districto_Tech.distribuidora.common.config.MapperConfig;
import com.Districto_Tech.distribuidora.features.employees.dtos.EmployeeRequestDTO;
import com.Districto_Tech.distribuidora.features.employees.dtos.EmployeeResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class EmployeeModelMapper implements IModelMapper<EmployeeEntity, EmployeeResponseDTO, EmployeeRequestDTO> {

    private MapperConfig mapperConfig;

    @Override
    public EmployeeEntity toEntity(EmployeeRequestDTO dto) {
        EmployeeEntity entity = mapperConfig.modelMapper().map(dto, EmployeeEntity.class);
        return entity;
    }

    @Override
    public EmployeeResponseDTO toDto(EmployeeEntity employeeEntity) {
        return mapperConfig.modelMapper().map(employeeEntity, EmployeeResponseDTO.class);
    }
}
